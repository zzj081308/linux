import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 这个项目是纯静态的，没有任何后端调用，所以配置就这么简单。
//
// 以后如果要接后端（前端 fetch('/api/...')），在这里加一段开发代理，
// 避免本地开发时的跨域问题：
//
//   server: {
//     port: 5173,
//     proxy: {
//       '/api': { target: 'http://127.0.0.1:8080', changeOrigin: true },
//     },
//   },
//
// 注意 target 里的 127.0.0.1 指的是「运行 npm run dev 的那台机器」。
// 部署之后这段代理完全不生效，同样的转发角色由 nginx 的 location /api/ 承担
// —— 前端代码不用改一行。

export default defineConfig({
  plugins: [vue()],
})
