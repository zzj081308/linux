# vue-demo

一个最小的 Vue 3 + Vite 项目，用来练习 **「打包 → 上传 → nginx 托管」**。

没有后端，没有接口调用，就是几个静态页面。

## 本地运行

```shell
npm install
npm run dev
```

浏览器打开 http://localhost:5173

想先看看部署后的效果：

```shell
npm run build
npm run preview
```

## 打包

```shell
npm run build
```

产物在 `dist/`：一个 `index.html` + 一个 `assets/` 目录。
是纯静态文件，服务器上不需要 node。

## 部署到 nginx

```shell
mkdir -p /usr/share/nginx/html/vue-demo
cp -r dist/* /usr/share/nginx/html/vue-demo/
```

```nginx
server {
    listen       80;
    server_name  192.168.253.135;
    charset      utf-8;

    root  /usr/share/nginx/html/vue-demo;
    index index.html;

    # 唯一"Vue 特有"的一行：SPA 路由回退
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

```shell
nginx -t && systemctl reload nginx
firewall-cmd --add-port=80/tcp --permanent && firewall-cmd --reload
```

访问 http://192.168.253.135/

## 核心结论

> **nginx 部署 Vue 页面 = 部署一个静态网站 + 一行 `try_files`。**

除了那一行，跟部署普通静态 HTML 网站没有任何区别：不需要 node、
不需要后端、不涉及 SELinux（`/usr/share/nginx/html` 天生就是 nginx 能读的标签）。

## 页面

| 路径 | 内容 |
|---|---|
| `/` | 首页 |
| `/demo` | 交互演示（计数器 + 待办列表） |
| `/guide` | 部署要点：打包 / 上传 / nginx 配置 / try_files 原理 |
| `/about` | 项目结构、能踩到哪些坑 |
| `/guide/nginx` | 二级路径，用来验证 `try_files` 是否生效 |

**验证 try_files 的方法**：停在 `/demo` 或 `/guide` 上按 F5。
没配 `try_files` 会 404；配了就正常。

## 目录结构

```
vue-demo/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.js
    ├── style.css
    ├── App.vue
    ├── router/index.js
    └── views/
        ├── Home.vue
        ├── Demo.vue
        ├── Guide.vue
        └── About.vue
```
