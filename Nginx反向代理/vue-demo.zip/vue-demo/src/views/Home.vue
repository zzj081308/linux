<template>
  <section class="card">
    <h2>这是个用来练部署的项目</h2>
    <p>
      没有后端、没有接口调用，就是几个静态页面。唯一的目的：把
      <strong>「打包 → 上传 → nginx 托管」</strong>这条路完整走一遍。
    </p>
    <div class="note">
      先用导航点点看，切换页面一切正常。<br />
      然后停在 <code>/demo</code> 或 <code>/guide</code> 上按 <strong>F5 刷新</strong>
      —— 如果 nginx 没配 <code>try_files</code>，就会看到 404。
      <br />这就是部署 Vue 项目唯一需要额外注意的地方。
    </div>
  </section>

  <section class="card">
    <h2>页面导航</h2>
    <ul class="nav-list">
      <li>
        <RouterLink to="/demo">交互演示</RouterLink>
        <span>计数器 + 待办列表，看看 Vue 的响应式</span>
      </li>
      <li>
        <RouterLink to="/guide">部署要点</RouterLink>
        <span>打包、上传、nginx 配置全套</span>
      </li>
      <li>
        <RouterLink to="/about">关于</RouterLink>
        <span>项目结构，以及这个练习能踩到哪些坑</span>
      </li>
    </ul>
  </section>

  <section class="card">
    <h2>一个提醒</h2>
    <p>
      这个项目<strong>故意用了 history 路由模式</strong>（地址栏没有
      <code>#</code>），所以才有 <code>try_files</code> 这回事。
    </p>
    <p>
      如果你换成一个纯静态的 HTML 网站，压根不需要它 ——
      <strong>Vue 部署和普通静态网站部署的区别，就只有这一行配置。</strong>
    </p>
  </section>
</template>

<style scoped>
.nav-list {
  list-style: none;
  padding: 0;
  margin: 8px 0 0;
}

.nav-list li {
  padding: 10px 0;
  border-bottom: 1px solid var(--border);
}

.nav-list li:last-child {
  border-bottom: none;
}

.nav-list a {
  font-weight: 600;
  text-decoration: none;
}

.nav-list span {
  display: block;
  color: var(--muted);
  font-size: 14px;
}
</style>
