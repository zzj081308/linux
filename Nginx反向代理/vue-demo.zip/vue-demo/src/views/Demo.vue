<script setup>
import { ref, computed } from 'vue'

// ---- 计数器：演示响应式 ----
const count = ref(0)

// ---- 待办列表：演示列表渲染 + 事件 ----
let nextId = 4
const draft = ref('')
const items = ref([
  { id: 1, text: 'npm run build 打包', done: true },
  { id: 2, text: '把 dist 传到服务器', done: false },
  { id: 3, text: '配好 nginx 的 try_files', done: false },
])
const remaining = computed(() => items.value.filter((i) => !i.done).length)

function addItem() {
  const text = draft.value.trim()
  if (!text) return
  items.value.push({ id: nextId++, text, done: false })
  draft.value = ''
}

function removeItem(id) {
  items.value = items.value.filter((i) => i.id !== id)
}
</script>

<template>
  <section class="card">
    <h2>计数器</h2>
    <p>演示 Vue 的响应式：<code>count</code> 一变，用到它的地方全部自动更新。</p>

    <div class="counter">
      <button @click="count--">−</button>
      <strong>{{ count }}</strong>
      <button @click="count++">+</button>
    </div>

    <p class="muted">当前值是 {{ count }}，它的两倍是 {{ count * 2 }}</p>
  </section>

  <section class="card">
    <h2>待办列表</h2>
    <p>还有 <strong>{{ remaining }}</strong> 项没完成。</p>

    <form class="add-row" @submit.prevent="addItem">
      <input v-model="draft" placeholder="输入待办，回车添加" />
      <button type="submit">添加</button>
    </form>

    <ul class="todo">
      <li v-for="item in items" :key="item.id" :class="{ done: item.done }">
        <label>
          <input type="checkbox" v-model="item.done" />
          <span>{{ item.text }}</span>
        </label>
        <button class="del" @click="removeItem(item.id)">删除</button>
      </li>
    </ul>

    <div class="note">
      这些数据全在浏览器内存里 —— <strong>按 F5 刷新就回到初始状态</strong>。
      因为没有后端，没地方存。真实项目里这一步会调接口。
    </div>
  </section>
</template>

<style scoped>
.counter {
  display: flex;
  align-items: center;
  gap: 16px;
  margin: 14px 0;
}

.counter strong {
  font-size: 26px;
  min-width: 64px;
  text-align: center;
  font-variant-numeric: tabular-nums;
}

.counter button {
  width: 42px;
  padding: 6px 0;
  margin: 0;
  font-size: 18px;
  line-height: 1;
}

.muted {
  color: var(--muted);
  font-size: 14px;
}

.add-row {
  display: flex;
  gap: 8px;
  margin: 12px 0;
}

.add-row input {
  flex: 1;
  font: inherit;
  font-size: 14px;
  padding: 8px 12px;
  border: 1px solid var(--border);
  border-radius: 6px;
  background: #fff;
  color: var(--fg);
}

.add-row input:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-soft);
}

.add-row button {
  margin: 0;
}

.todo {
  list-style: none;
  padding: 0;
  margin: 8px 0 0;
}

.todo li {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 9px 0;
  border-bottom: 1px solid var(--border);
}

.todo label {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  flex: 1;
}

.todo li.done span {
  text-decoration: line-through;
  color: var(--muted);
}

.del {
  background: none;
  color: var(--muted);
  border: 1px solid var(--border);
  padding: 4px 12px;
  font-size: 13px;
  margin: 0;
}

.del:hover {
  color: var(--danger);
  border-color: #fecaca;
  background: var(--danger-soft);
  opacity: 1;
}
</style>
