<template>
  <section class="card">
    <h2>这是个什么项目</h2>
    <p>
      一个刻意做得最小的 Vue 3 + Vite 项目。没有后端、没有接口调用，
      就是几个静态页面。
    </p>
    <p><strong>唯一的用途</strong>：把「打包 → 上传 → nginx 托管」这条路完整走一遍。</p>
    <p>结构上跟真实项目一样，该有的都有：</p>
    <ul>
      <li>Vue 3 <code>&lt;script setup&gt;</code> 单文件组件</li>
      <li>Vue Router（history 模式，故意留了个二级路径）</li>
      <li>一个有点交互的页面，用来确认打包后 JS 确实正常工作</li>
    </ul>
  </section>

  <section class="card">
    <h2>目录结构</h2>
    <pre><code>vue-demo/
├── index.html          ← 唯一入口，注意 &lt;meta charset="UTF-8"&gt;
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.js
    ├── style.css
    ├── App.vue         ← 导航 + RouterView + 当前路由显示
    ├── router/
    │   └── index.js    ← 路由表，含二级路径 /guide/nginx
    └── views/
        ├── Home.vue    首页
        ├── Demo.vue    交互演示（计数器 + 待办）
        ├── Guide.vue   部署要点
        └── About.vue   本页</code></pre>
  </section>

  <section class="card">
    <h2>本地跑起来</h2>
    <pre><code>npm install
npm run dev</code></pre>
    <p>浏览器打开 <code>http://localhost:5173</code>。</p>
    <p>也可以先打包再本地预览，看看部署后的真实效果：</p>
    <pre><code>npm run build
npm run preview</code></pre>
  </section>

  <section class="card">
    <h2>这个练习能踩到哪些坑</h2>
    <table>
      <thead>
        <tr>
          <th>现象</th>
          <th>知识点</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>刷新 <code>/demo</code>、<code>/guide</code> 报 404</td>
          <td><code>try_files</code> 与 SPA history 路由</td>
        </tr>
        <tr>
          <td>页面中文乱码</td>
          <td><code>&lt;meta charset&gt;</code> 与响应头 charset</td>
        </tr>
        <tr>
          <td>发版后用户还看到旧页面</td>
          <td>HTML 与静态资源的缓存策略</td>
        </tr>
        <tr>
          <td>dist 放自定义目录后 nginx 读不了</td>
          <td>SELinux 文件标签（<code>semanage fcontext</code> + <code>restorecon</code>）</td>
        </tr>
        <tr>
          <td>外部访问不到 80</td>
          <td>防火墙放行（<code>firewall-cmd --add-port</code>）</td>
        </tr>
      </tbody>
    </table>
    <div class="note">
      <strong>打包命令写错了会怎样？</strong>
      如果 <code>dist/</code> 里只有 <code>index.html</code> 没有
      <code>assets/</code>，页面会白屏 —— 因为 JS 没加载上。
      按 F12 看 Console 一般能看到 404。
    </div>
  </section>
</template>
