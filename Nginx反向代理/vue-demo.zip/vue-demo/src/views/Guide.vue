<template>
  <section class="card">
    <h2>1. 打包</h2>
    <pre><code>npm install
npm run build</code></pre>
    <p>
      产物在 <code>dist/</code> 目录：一个 <code>index.html</code>，加一个
      <code>assets/</code> 目录（js、css 都在里面，文件名带 hash）。
    </p>
    <div class="note">
      打包后就是<strong>纯静态文件</strong>。服务器上不需要装 node，也不用跑 npm
      —— nginx 直接读文件往外发就行。
    </div>
  </section>

  <section class="card">
    <h2>2. 上传到服务器</h2>
    <pre><code>mkdir -p /usr/share/nginx/html/vue-demo
cp -r dist/* /usr/share/nginx/html/vue-demo/
ls /usr/share/nginx/html/vue-demo</code></pre>
    <div class="note warn">
      <strong>为什么放 /usr/share/nginx/html/ 下？</strong><br />
      这个目录天生带 <code>httpd_sys_content_t</code> 标签，nginx 能直接读。
      放到别处（比如 <code>/export/server/web</code>）会撞 SELinux：
      <code>open() "..." failed (13: Permission denied)</code>，
      得用 <code>semanage fcontext</code> + <code>restorecon</code> 补标签。
    </div>
  </section>

  <section class="card">
    <h2>3. nginx 配置</h2>
    <p>新建一个站点配置（原来那个 default.conf 可以先改后缀停用）：</p>
    <pre><code>mv /etc/nginx/conf.d/default.conf /etc/nginx/conf.d/default.conf.bak
vi /etc/nginx/conf.d/vue-demo.conf</code></pre>
    <pre><code>server {
    listen       80;
    server_name  192.168.253.135;
    charset      utf-8;

    root  /usr/share/nginx/html/vue-demo;
    index index.html;

    # 整个部署里最关键的、也是唯一"Vue 特有"的一行
    location / {
        try_files $uri $uri/ /index.html;
    }
}</code></pre>
    <pre><code>nginx -t && systemctl reload nginx</code></pre>
    <p>
      然后浏览器访问 <code>http://192.168.253.135/</code>。
      防火墙记得放行 80：<code>firewall-cmd --add-port=80/tcp --permanent && firewall-cmd --reload</code>
    </p>
  </section>

  <section class="card">
    <h2>为什么 try_files 必须有</h2>
    <p>Vue Router 用的是 history 模式，地址栏长得像真实路径：</p>
    <pre><code>http://你的域名/demo
http://你的域名/guide</code></pre>
    <p>
      但服务器上<strong>根本没有这几个文件</strong>，只有 <code>index.html</code>
      —— 路由是浏览器里跑起来的 JS 干的活。
    </p>
    <ul>
      <li><strong>从首页点导航跳过去</strong> —— 前端路由拦下了，不会真的请求服务器，正常</li>
      <li>
        <strong>在那个页面按 F5</strong> —— 浏览器真的去请求 <code>/demo</code>，
        nginx 找文件找不到 → <strong>404</strong>
      </li>
    </ul>
    <p>解决办法就是让 nginx「找不到文件就返回 index.html」：</p>
    <pre><code>location / {
    try_files $uri $uri/ /index.html;
}</code></pre>
    <div class="note">
      <code>try_files</code> 的含义是依次尝试：<code>$uri</code>（这个路径有文件吗）
      → <code>$uri/</code>（当目录呢）→ 都没有就返回 <code>/index.html</code>。<br />
      回到 index.html 后，前端路由再看一眼地址栏，把对应页面渲染出来。
    </div>
    <p>
      想省掉这个配置也行 —— 把路由改成 <code>createWebHashHistory()</code>，
      地址会变成 <code>/#/demo</code>。URL 丑一点，但刷新永远不会 404。
    </p>
  </section>

  <section class="card">
    <h2>以后要接后端怎么办（现在可以跳过）</h2>
    <p>
      真实项目里前端往往还要调接口。到时候在同一个 server 里加一段
      <code>location /api/</code>，把接口请求转发给后端：
    </p>
    <pre><code>location /api/ {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host            $host;
    proxy_set_header X-Real-IP       $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}</code></pre>
    <p>
      好处是<strong>同一个域名、同一个端口</strong>下既有页面又有接口，
      靠 <code>location</code> 区分，浏览器看来是同一个源 ——
      <strong>不会有跨域问题</strong>。
    </p>
    <div class="note warn">
      这一步会引入新的坑：后端没起来会 502；如果 nginx 被 SELinux 拦了对外连接，
      还要 <code>setsebool -P httpd_can_network_connect on</code>。
      但这个项目<strong>现在完全不需要</strong> —— 先把静态部署跑通再说。
    </div>
  </section>
</template>
