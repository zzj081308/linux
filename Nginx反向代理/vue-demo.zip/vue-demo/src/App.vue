<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const currentPath = computed(() => route.fullPath)
</script>

<template>
  <div class="page">
    <header>
      <h1>vue-demo</h1>
      <p class="sub">一个最小 Vue 项目，用来练习「打包 → 上传 → nginx 托管」</p>
      <nav>
        <RouterLink to="/">首页</RouterLink>
        <RouterLink to="/demo">交互演示</RouterLink>
        <RouterLink to="/guide">部署要点</RouterLink>
        <RouterLink to="/about">关于</RouterLink>
      </nav>
    </header>

    <main>
      <RouterView />
    </main>

    <footer>
      当前路由：<code>{{ currentPath }}</code>
      <br />
      在这个页面按 F5 刷新试试 —— nginx 没配 <code>try_files</code> 的话，
      除了首页以外的路径都会 404。
    </footer>
  </div>
</template>
