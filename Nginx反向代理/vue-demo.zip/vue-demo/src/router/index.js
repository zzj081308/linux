import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Demo from '../views/Demo.vue'
import Guide from '../views/Guide.vue'
import About from '../views/About.vue'

const routes = [
  { path: '/', name: 'home', component: Home },
  { path: '/demo', name: 'demo', component: Demo },
  { path: '/guide', name: 'guide', component: Guide },
  { path: '/about', name: 'about', component: About },

  // 故意加一个二级路径，用来演示 nginx 的 try_files：
  // 直接访问 /guide/nginx 或在那个页面按 F5，nginx 在磁盘上找不到
  // 名为 "guide/nginx" 的文件，只能回退到 index.html 交给前端路由。
  // 没配 try_files 的话，这里就是 404。
  { path: '/guide/nginx', name: 'guide-nginx', component: Guide },
]

// createWebHistory = history 模式，地址栏没有 #，看起来干净
// 但刷新任意子路径都需要服务端配合（就是上面说的 try_files）
//
// 想省掉这个配置可以用 createWebHashHistory()，地址会变成 /#/guide
const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
